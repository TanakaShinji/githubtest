class Ticket
  def initialize(movie)
    @title = movie.title
    @fee = movie.fee
  end
end